# back compatibility package for any code explicitly checking
# that the filehandle object is a Fh
package Fh;

$Fh::VERSION = '4.21';

1;
